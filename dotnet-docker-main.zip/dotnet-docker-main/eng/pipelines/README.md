The contents of the `pipelines` folder are used by the .NET Core engineering infrastructure to build and publish the images.
