This image contains the .NET runtimes and libraries and is optimized for running .NET apps in production.
