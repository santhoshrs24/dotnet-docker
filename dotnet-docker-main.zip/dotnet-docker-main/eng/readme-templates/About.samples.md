These images contain sample .NET and ASP.NET Core applications.
