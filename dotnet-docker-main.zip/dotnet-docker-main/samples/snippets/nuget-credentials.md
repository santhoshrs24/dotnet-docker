# Content has Moved

This file has moved to a new [location](../../documentation/scenarios/nuget-credentials.md).
