# Content has Moved

This file has moved to a new [location](../../documentation/scenarios/using-system-drawing-common.md).
